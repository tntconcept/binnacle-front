import{az as s,aV as r}from"./vendor.651f4eea.js";import{u as t}from"./useTitle.671ca542.js";const m=({children:e,title:a})=>(t(a),s(r,{children:e}));export{m as P};
