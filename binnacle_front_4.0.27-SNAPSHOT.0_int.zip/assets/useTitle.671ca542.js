import{aw as t}from"./vendor.651f4eea.js";const s=e=>{t.exports.useEffect(()=>{document.title=e},[e])};export{s as u};
